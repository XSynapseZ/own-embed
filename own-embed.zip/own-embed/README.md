# Own Embed — TMDB player (any device)

Self-hosted embed. Resolves streams by TMDB ID. Works on desktop, Android, and iPhone Safari.

## Deploy on Render

1. Push this folder to a GitHub repo (or connect the folder).
2. New → Web Service → select the repo.
3. Settings:
   - **Runtime:** Node
   - **Build:** `npm install`
   - **Start:** `npm start`
   - **Node version:** 20
4. Deploy. Use the Render URL:

```
https://YOUR-SERVICE.onrender.com/embed/movie/550
https://YOUR-SERVICE.onrender.com/embed/tv/1399/1/1
```

Or use the included `render.yaml` (Blueprint).

## Local

```bash
npm install
npm start
```

Port defaults to `8787` (or `$PORT` on Render).

## Embed (iframe — any site / any device)

```html
<iframe
  src="https://YOUR-SERVICE.onrender.com/embed/movie/550"
  style="width:100%;height:100%;border:0;aspect-ratio:16/9"
  allow="autoplay; fullscreen; picture-in-picture; encrypted-media"
  allowfullscreen
  playsinline
></iframe>
```

TV:

```html
<iframe
  src="https://YOUR-SERVICE.onrender.com/embed/tv/1399/1/1"
  style="width:100%;height:100%;border:0"
  allow="autoplay; fullscreen; picture-in-picture; encrypted-media"
  allowfullscreen
></iframe>
```

## Device support

| Platform | Playback |
|---|---|
| iPhone / iPad Safari | Native HLS (`playsinline`) |
| Android Chrome | HLS.js |
| Desktop Chrome / Firefox / Edge | HLS.js |
| Desktop Safari | Native HLS |

Server badges at the top switch providers. First working provider auto-plays.

## API

| Endpoint | Use |
|---|---|
| `GET /health` | Render health check |
| `GET /api/catalog?type=movie&id=550` | Provider list |
| `GET /api/stream/provider?type=movie&id=550&provider=ID` | Resolve one stream |
| `GET /api/stream/live?type=movie&id=550` | SSE first stream |

TV: add `&season=1&episode=1`.

## Notes

- Upstream is still cinesrc.st (your player + domain; their mirrors).
- Free Render instances sleep; first request after idle can take ~30–60s.
- If `canvas` build fails on Render, the free Linux plan usually has the needed libs; if not, switch to a paid instance or use a Docker-based host.
