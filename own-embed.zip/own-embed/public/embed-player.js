/**
 * Cross-device embed player (desktop + iOS Safari + Android Chrome).
 * Routes:
 *   /embed/movie/{tmdbId}
 *   /embed/tv/{tmdbId}/{season}/{episode}
 * Query fallback: ?type=movie&id=550  |  ?type=tv&id=1399&season=1&episode=1
 */

import Hls from '/vendor/hls.mjs'

const video = document.getElementById('video')
const overlay = document.getElementById('overlay')
const statusEl = document.getElementById('status')
const errEl = document.getElementById('err')
const serversEl = document.getElementById('servers')

let hls = null
let catalog = []
let activeId = null
const cache = new Map()

const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) ||
  (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1)
const canNativeHls = video.canPlayType('application/vnd.apple.mpegurl') !== ''

function parseRoute() {
  const path = location.pathname.replace(/\/+$/, '')
  const movie = path.match(/\/embed\/movie\/(\d+)/)
  if (movie) return { type: 'movie', id: movie[1] }
  const tv = path.match(/\/embed\/tv\/(\d+)\/(\d+)\/(\d+)/)
  if (tv) return { type: 'tv', id: tv[1], season: tv[2], episode: tv[3] }
  const q = new URLSearchParams(location.search)
  const type = q.get('type') === 'tv' ? 'tv' : 'movie'
  const id = q.get('id') || q.get('tmdb')
  if (!id) return null
  if (type === 'tv') {
    return {
      type,
      id,
      season: q.get('season') || '1',
      episode: q.get('episode') || '1',
    }
  }
  return { type, id }
}

function qs(params) {
  const p = new URLSearchParams({ type: params.type, id: params.id })
  if (params.type === 'tv') {
    p.set('season', params.season)
    p.set('episode', params.episode)
  }
  return p.toString()
}

function setStatus(text) {
  statusEl.textContent = text
  overlay.classList.remove('hidden')
  errEl.hidden = true
}

function setError(text) {
  statusEl.textContent = 'Failed'
  errEl.textContent = text
  errEl.hidden = false
  overlay.classList.remove('hidden')
}

function hideOverlay() {
  overlay.classList.add('hidden')
}

function stop() {
  if (hls) {
    try { hls.destroy() } catch (_) {}
    hls = null
  }
  video.removeAttribute('src')
  video.load()
}

function playUrl(url) {
  stop()
  const isHls = /\.m3u8(\?|$)/i.test(url)

  // iOS / Safari: prefer native HLS
  if (isHls && canNativeHls) {
    video.src = url
    const onReady = () => {
      hideOverlay()
      video.play().catch(() => {})
    }
    video.addEventListener('loadedmetadata', onReady, { once: true })
    video.addEventListener('error', () => setError('Playback error'), { once: true })
    return
  }

  // MSE browsers: HLS.js
  if (isHls && Hls.isSupported()) {
    hls = new Hls({
      enableWorker: true,
      lowLatencyMode: false,
      maxBufferLength: 30,
      maxMaxBufferLength: 60,
      xhrSetup: (xhr) => {
        // some CDNs need no credentials
        xhr.withCredentials = false
      },
    })
    hls.loadSource(url)
    hls.attachMedia(video)
    hls.on(Hls.Events.MANIFEST_PARSED, () => {
      hideOverlay()
      video.play().catch(() => {})
    })
    hls.on(Hls.Events.ERROR, (_, data) => {
      if (data.fatal) {
        if (data.type === Hls.ErrorTypes.NETWORK_ERROR) {
          hls.startLoad()
        } else if (data.type === Hls.ErrorTypes.MEDIA_ERROR) {
          hls.recoverMediaError()
        } else {
          setError('Stream error: ' + (data.details || data.type))
        }
      }
    })
    return
  }

  // Progressive / MP4
  video.src = url
  video.addEventListener('loadeddata', () => {
    hideOverlay()
    video.play().catch(() => {})
  }, { once: true })
  video.addEventListener('error', () => setError('Playback error'), { once: true })
}

function renderServers() {
  serversEl.innerHTML = catalog.map((p) => {
    const cls = [
      'badge',
      p.id === activeId ? 'active' : '',
      p._state === 'loading' ? 'loading' : '',
      p._state === 'failed' ? 'failed' : '',
    ].filter(Boolean).join(' ')
    const label = (p.name || p.id).replace(/</g, '&lt;')
    return `<button type="button" class="${cls}" data-id="${p.id}">${label}</button>`
  }).join('')
  serversEl.querySelectorAll('button').forEach((btn) => {
    btn.addEventListener('click', () => resolveAndPlay(btn.dataset.id))
  })
}

async function loadCatalog(params) {
  setStatus('Fetching servers…')
  const res = await fetch('/api/catalog?' + qs(params), { credentials: 'omit' })
  const data = await res.json().catch(() => ({}))
  if (!res.ok) throw new Error(data.error || 'catalog failed (' + res.status + ')')
  catalog = (data.providers || []).map((p) => ({ ...p, _state: 'idle' }))
  if (!catalog.length) throw new Error('No providers for this title')
  renderServers()
}

async function resolveAndPlay(providerId) {
  const entry = catalog.find((p) => p.id === providerId)
  if (!entry) return

  if (cache.has(providerId)) {
    activeId = providerId
    renderServers()
    setStatus('Playing…')
    playUrl(cache.get(providerId))
    return
  }

  entry._state = 'loading'
  renderServers()
  setStatus('Resolving ' + (entry.name || providerId) + '…')

  try {
    const res = await fetch(
      '/api/stream/provider?' + qs(window.__params) + '&provider=' + encodeURIComponent(providerId),
      { credentials: 'omit' }
    )
    const data = await res.json().catch(() => ({}))
    if (!res.ok || !data.ok || !data.url) {
      entry._state = 'failed'
      renderServers()
      setError(data.reason || data.error || 'No stream from this server')
      return
    }
    cache.set(providerId, data.url)
    entry._state = 'ok'
    activeId = providerId
    renderServers()
    playUrl(data.url)
  } catch (e) {
    entry._state = 'failed'
    renderServers()
    setError(String(e.message || e))
  }
}

async function boot() {
  const params = parseRoute()
  if (!params) {
    setError('Missing TMDB id. Use /embed/movie/{id} or /embed/tv/{id}/{s}/{e}')
    return
  }
  window.__params = params
  try {
    await loadCatalog(params)
    await resolveAndPlay(catalog[0].id)
  } catch (e) {
    setError(String(e.message || e))
  }
}

boot()
