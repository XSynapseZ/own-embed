import http from 'node:http'
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { parseStreamQuery, fetchProviderCatalog, resolveProviderStream, resolveFirstStream } from './resolve/live.js'

const root = path.dirname(fileURLToPath(import.meta.url))
const publicDir = path.join(root, '../public')
const hlsPath = path.join(root, '../node_modules/hls.js/dist/hls.mjs')
const port = Number(process.env.PORT) || 8787

const MIME = {
  '.css': 'text/css; charset=utf-8',
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.wasm': 'application/wasm',
  '.json': 'application/json; charset=utf-8',
  '.ico': 'image/x-icon',
  '.png': 'image/png',
  '.svg': 'image/svg+xml',
}

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Accept',
}

function json(res, status, body) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', ...cors })
  res.end(JSON.stringify(body))
}

function query(url) {
  return Object.fromEntries(new URL(url, 'http://local').searchParams.entries())
}

function sse(res, event, data) {
  res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`)
}

function serveStatic(pathOnly, res) {
  const rel = pathOnly === '/' ? 'index.html' : pathOnly.slice(1)
  const filePath = path.resolve(publicDir, rel)
  if (!filePath.startsWith(publicDir) || !fs.existsSync(filePath) || !fs.statSync(filePath).isFile()) {
    return false
  }
  const ext = path.extname(filePath)
  res.writeHead(200, {
    'Content-Type': MIME[ext] || 'application/octet-stream',
    'Cache-Control': ext === '.html' ? 'no-cache' : 'public, max-age=3600',
    ...cors,
  })
  res.end(fs.readFileSync(filePath))
  return true
}

function serveEmbed(res) {
  const filePath = path.join(publicDir, 'embed.html')
  res.writeHead(200, {
    'Content-Type': MIME['.html'],
    'Cache-Control': 'no-cache',
    ...cors,
  })
  res.end(fs.readFileSync(filePath))
}

async function apiJson(res, handler) {
  try {
    json(res, 200, await handler())
  } catch (error) {
    json(res, 502, { error: String(error.message || error) })
  }
}

const server = http.createServer(async (req, res) => {
  try {
    if (req.method === 'OPTIONS') {
      res.writeHead(204, cors)
      res.end()
      return
    }

    const pathOnly = (req.url || '/').split('?')[0]

    // Own embed surface (TMDB IDs) — works in iframe on any device
    if (req.method === 'GET' && /^\/embed\/movie\/\d+\/?$/.test(pathOnly)) {
      return serveEmbed(res)
    }
    if (req.method === 'GET' && /^\/embed\/tv\/\d+\/\d+\/\d+\/?$/.test(pathOnly)) {
      return serveEmbed(res)
    }
    if (req.method === 'GET' && pathOnly === '/embed') {
      return serveEmbed(res)
    }

    if (req.method === 'GET' && serveStatic(pathOnly, res)) return

    if (req.method === 'GET' && pathOnly === '/vendor/hls.mjs') {
      if (!fs.existsSync(hlsPath)) {
        return json(res, 500, { error: 'hls.js not installed. Run npm install.' })
      }
      res.writeHead(200, {
        'Content-Type': MIME['.mjs'],
        'Cache-Control': 'public, max-age=86400',
        ...cors,
      })
      res.end(fs.readFileSync(hlsPath))
      return
    }

    if (req.method === 'GET' && pathOnly === '/health') {
      return json(res, 200, { ok: true })
    }

    if (req.method === 'GET' && pathOnly === '/api/catalog') {
      const parsed = parseStreamQuery(query(req.url))
      if (parsed.error) return json(res, 400, { error: parsed.error })
      return apiJson(res, () => fetchProviderCatalog(parsed))
    }

    if (req.method === 'GET' && pathOnly === '/api/stream/provider') {
      const params = query(req.url)
      const parsed = parseStreamQuery(params)
      if (parsed.error) return json(res, 400, { error: parsed.error })
      if (!params.provider) return json(res, 400, { error: 'Provider id is required.' })
      return apiJson(res, () => resolveProviderStream(parsed, params.provider))
    }

    if (req.method === 'GET' && pathOnly === '/api/stream/live') {
      const parsed = parseStreamQuery(query(req.url))
      if (parsed.error) return json(res, 400, { error: parsed.error })
      res.writeHead(200, {
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache, no-transform',
        Connection: 'keep-alive',
        'X-Accel-Buffering': 'no',
        ...cors,
      })
      res.flushHeaders?.()
      res.socket?.setNoDelay(true)
      try {
        await resolveFirstStream(parsed, (event, data) => sse(res, event, data))
      } catch (error) {
        sse(res, 'fail', { error: String(error.message || error) })
      }
      res.end()
      return
    }

    json(res, 404, { error: 'Not found.' })
  } catch (error) {
    json(res, 500, { error: String(error.message || error) })
  }
})

server.on('connection', (socket) => socket.setNoDelay(true))

// Render / PaaS bind to 0.0.0.0
const host = process.env.HOST || '0.0.0.0'
server.listen(port, host, () => {
  console.log(`Own embed listening on http://${host}:${port}`)
  console.log(`  Movie: /embed/movie/550`)
  console.log(`  TV:    /embed/tv/1399/1/1`)
  console.log(`  Health: /health`)
})
